import { GridClasses } from '@mui/system/Unstable_Grid';
export type Grid2ClassKey = keyof GridClasses;
export declare function getGrid2UtilityClass(slot: string): string;
declare const grid2Classes: GridClasses;
export default grid2Classes;
