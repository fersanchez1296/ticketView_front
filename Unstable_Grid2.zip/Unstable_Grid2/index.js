'use client';

export { default } from './Grid2';
export * from './Grid2Props';
export { default as grid2Classes } from './grid2Classes';
export * from './grid2Classes';